package collector

import (
	"github.com/prometheus/client_golang/prometheus"
	"strconv"
	"strings"
)

// eip_rip_bytes{direction="In",eip="10.178.80.182",rip="10.0.0.206"} 3.86715634e+08
// eip_rip_bytes{direction="Out",eip="10.178.80.211",rip="10.65.10.62"} 1.74236779e+08

type BaseData struct {
	Eip       []string
	Rip       []string
	In_Bytes  []float64
	Out_Bytes []float64
}

func NewBaseData(output []string) BaseData {
	var eip = make([]string, len(output))
	var rip = make([]string, len(output))
	var in_bytes = make([]float64, len(output))
	var out_bytes = make([]float64, len(output))
	for i := 0; i < len(output); i++ {
		opslice := strings.Fields(output[i])
		if i == 0 {
			continue
		}

		eip[i] = opslice[0]
		rip[i] = opslice[1]
		s2_in_bytes, _ := strconv.ParseFloat(opslice[4], 64)
		s2_out_bytes, _ := strconv.ParseFloat(opslice[5], 64)
		in_bytes[i] = s2_in_bytes
		out_bytes[i] = s2_out_bytes

	}
	return BaseData{
		Eip:       eip,
		Rip:       rip,
		In_Bytes:  in_bytes,
		Out_Bytes: out_bytes,
	}
}

type TrafficCollector struct {
	BaseData
	desc *prometheus.Desc
}

func NewTrafficCollector(output []string) *TrafficCollector {
	desc := prometheus.NewDesc("eip_rip_bytes", "eip rip bytes", []string{"eip", "rip", "direction"}, nil)
	return &TrafficCollector{NewBaseData(output), desc}
}

func (c *TrafficCollector) Describe(descs chan<- *prometheus.Desc) {
	descs <- c.desc
}

func (c *TrafficCollector) Collect(metrics chan<- prometheus.Metric) {

	for i := 1; i < len(c.Eip)-1; i++ {
		metrics <- prometheus.MustNewConstMetric(c.desc, prometheus.GaugeValue, c.In_Bytes[i], c.Eip[i], c.Rip[i], "In")
		metrics <- prometheus.MustNewConstMetric(c.desc, prometheus.GaugeValue, c.In_Bytes[i], c.Eip[i], c.Rip[i], "Out")
	}

}
