package main

import (
	"eip-nat-exporter/eip-exproter/collector"
	"eip-nat-exporter/utils"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"net/http"
)

// 单独测试模块

func main() {
	configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\eip-exproter\\config.txt"
	var output = utils.ReadFromConfig(configPath)

	prometheus.MustRegister(collector.NewTrafficCollector(output))

	http.Handle("/metrics/", promhttp.Handler())
	http.ListenAndServe(":9999", nil)
}
