package main

import (
	eip_collector "eip-nat-exporter/eip-exproter/collector"
	nat_collector "eip-nat-exporter/nat-exporter/collector"
	service_collector "eip-nat-exporter/service-exporter/collector"
	"eip-nat-exporter/service-exporter/datadeal"
	"eip-nat-exporter/utils"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"net/http"
)

func main() {
	eip_traffic_configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\eip-exproter\\config.txt"
	var output = utils.ReadFromConfig(eip_traffic_configPath)
	prometheus.MustRegister(eip_collector.NewTrafficCollector(output))
	nat_traffic_configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\nat-exporter\\config.txt"
	output = utils.ReadFromConfig(nat_traffic_configPath)
	prometheus.MustRegister(nat_collector.NewNatTrafficCollector(output))
	service_configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\service-exporter\\config.txt"
	output = utils.ReadFromConfig(service_configPath)
	mp := datadeal.Trans(output)
	prometheus.MustRegister(service_collector.NewServiceCollector(mp))
	http.Handle("/metrics/", promhttp.Handler())
	http.ListenAndServe(":9999", nil)
}
