package main

import (
	"eip-nat-exporter/utils"
	"fmt"
)
import "eip-nat-exporter/service-exporter/datadeal"

func main() {
	configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\service-exporter\\config.txt"
	output := utils.ReadFromConfig(configPath)
	mp := datadeal.Trans(output)
	for k, v := range mp {
		fmt.Println(k, v)
	}
}
