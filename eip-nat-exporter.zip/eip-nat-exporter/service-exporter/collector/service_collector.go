package collector

import (
	"github.com/prometheus/client_golang/prometheus"
	"strconv"
)

// 通过ip:port 确定实例
type baseData struct {
	ip             []string
	port           []string
	in_bytes       []float64
	out_bytes      []float64
	create_conns   []float64
	active_conns   []float64
	inactive_conns []float64
}

func NewBaseData(mp map[string][]string) baseData {
	// 将mp中的字符串类型转为baseData中对应的类型
	in_bytes_array := make([]float64, 0)
	for _, v := range mp["inbytes"] {
		f, _ := strconv.ParseFloat(v, 64)
		in_bytes_array = append(in_bytes_array, f)
	}
	out_bytes_array := make([]float64, 0)
	for _, v := range mp["outbytes"] {
		f, _ := strconv.ParseFloat(v, 64)
		out_bytes_array = append(out_bytes_array, f)
	}
	create_conns := make([]float64, 0)
	for _, v := range mp["create_conns"] {
		f, _ := strconv.ParseFloat(v, 64)
		create_conns = append(create_conns, f)
	}
	active_conns := make([]float64, 0)
	for _, v := range mp["local_active_conns"] {
		f, _ := strconv.ParseFloat(v, 64)
		active_conns = append(active_conns, f)
	}
	inactive_conns := make([]float64, 0)
	for _, v := range mp["local_inactive_conns"] {
		f, _ := strconv.ParseFloat(v, 64)
		inactive_conns = append(inactive_conns, f)
	}
	return baseData{
		ip:             mp["ip"],
		port:           mp["port"],
		in_bytes:       in_bytes_array,
		out_bytes:      out_bytes_array,
		create_conns:   create_conns,
		active_conns:   active_conns,
		inactive_conns: inactive_conns,
	}
}

type serviceCollector struct {
	baseData
	service_traffic_desc *prometheus.Desc
	active_conns_desc    *prometheus.Desc
	inactive_conns_desc  *prometheus.Desc
	create_conns_desc    *prometheus.Desc
}

func NewServiceCollector(mp map[string][]string) *serviceCollector {
	service_traffic_desc := prometheus.NewDesc("service_traffic", "service traffic", []string{"endpoints", "direction"}, nil)
	active_conns_desc := prometheus.NewDesc("active_conns", "active conns", []string{"endpoints"}, nil)
	inactive_conns_desc := prometheus.NewDesc("inactive_conns", "inactive conns", []string{"endpoints"}, nil)
	create_conns_desc := prometheus.NewDesc("create_conns", "create conns", []string{"endpoints"}, nil)
	return &serviceCollector{
		baseData:             NewBaseData(mp),
		service_traffic_desc: service_traffic_desc,
		active_conns_desc:    active_conns_desc,
		inactive_conns_desc:  inactive_conns_desc,
		create_conns_desc:    create_conns_desc,
	}
}

func (c *serviceCollector) Describe(descs chan<- *prometheus.Desc) {
	descs <- c.service_traffic_desc
	descs <- c.active_conns_desc
	descs <- c.inactive_conns_desc
	descs <- c.create_conns_desc
}

func (c *serviceCollector) Collect(metrics chan<- prometheus.Metric) {
	lens := len(c.ip)
	for i := 0; i < lens; i++ {
		endpoints := c.ip[i] + ":" + c.port[i]
		metrics <- prometheus.MustNewConstMetric(c.service_traffic_desc, prometheus.GaugeValue, c.in_bytes[i], endpoints, "IN")
		metrics <- prometheus.MustNewConstMetric(c.service_traffic_desc, prometheus.GaugeValue, c.out_bytes[i], endpoints, "OUT")
		metrics <- prometheus.MustNewConstMetric(c.inactive_conns_desc, prometheus.GaugeValue, c.inactive_conns[i], endpoints)
		metrics <- prometheus.MustNewConstMetric(c.create_conns_desc, prometheus.GaugeValue, c.create_conns[i], endpoints)
		metrics <- prometheus.MustNewConstMetric(c.active_conns_desc, prometheus.GaugeValue, c.active_conns[i], endpoints)
	}
}
