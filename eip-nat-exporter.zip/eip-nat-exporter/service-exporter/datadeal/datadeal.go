package datadeal

import (
	"regexp"
	"strings"
)

// 节点SLB实例流量
// inbytes在 i+1  outbytes 在i+2  curr_sync_conns 在i+7
////IP := `127.0.0.1|0.0.0.0|localhost|192\.\d{1,3}\.\d{1,3}\.\d{1,3}|198\.\d{1,3}\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.\d{1,3}\.\d{1,3}\.\d{1,3}`
////r, _ := regexp.Compile(IP)
//vs := `VS (?P<ip>[\d\.]+[\d\.]+[\d\.]+[\d\.]+):(?P<port>\d+)\((?P<protocol>\w+)\)\((\w+:\d{1,5})\)`
//r1, _ := regexp.Compile(vs)
//fmt.Println(r1.FindString("VS 10.21.1.69:3309(tcp)(vni:8184)"))

func Trans(output []string) map[string][]string {
	var mp = make(map[string][]string, 0)
	for i := 0; i < len(output); i++ {
		VS := `VS (?P<ip>[\d\.]+[\d\.]+[\d\.]+[\d\.]+):(?P<port>\d+)\((?P<protocol>\w+)\)\((\w+:\d{1,5})\)`
		IP_PORT := `(?P<ip>127.0.0.1|0.0.0.0|localhost|192\.\d{1,3}\.\d{1,3}\.\d{1,3}|198\.\d{1,3}\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.\d{1,3}\.\d{1,3}\.\d{1,3}):(?P<port>\d+)`
		r, _ := regexp.Compile(VS)
		if r.MatchString(output[i]) {
			r, _ = regexp.Compile(IP_PORT)
			ip_port_str := r.FindString(output[i])
			ip_port_sli := strings.Split(ip_port_str, ":")
			ip := ip_port_sli[0]
			port := ip_port_sli[1]
			in_bytes_str := strings.ReplaceAll(output[i+2], ":", " ")
			out_bytes_str := strings.ReplaceAll(output[i+3], ":", " ")
			local_active_conns_str := strings.ReplaceAll(output[i+5], ":", " ")
			local_inactive_conns_str := strings.ReplaceAll(output[i+6], ":", " ")
			create_conns_str := strings.ReplaceAll(output[i+11], ":", " ")
			in_bytes_sli := strings.Fields(in_bytes_str)
			out_bytes_sli := strings.Fields(out_bytes_str)
			create_conns_sli := strings.Fields(create_conns_str)
			local_active_conns_sli := strings.Fields(local_active_conns_str)
			local_inactive_conns_sli := strings.Fields(local_inactive_conns_str)
			mp["ip"] = append(mp["ip"], ip)
			mp["port"] = append(mp["port"], port)
			if strings.EqualFold(in_bytes_sli[0], "inbytes") && strings.EqualFold(out_bytes_sli[0], "outbytes") && strings.EqualFold(create_conns_sli[0], "create_conns") && strings.EqualFold(local_active_conns_sli[0], "local_active_conns") && strings.EqualFold(local_inactive_conns_sli[0], "local_inactive_conns") {
				mp["inbytes"] = append(mp["inbytes"], in_bytes_sli[1])
				mp["outbytes"] = append(mp["outbytes"], out_bytes_sli[1])
				mp["create_conns"] = append(mp["create_conns"], create_conns_sli[1])
				mp["local_active_conns"] = append(mp["local_active_conns"], local_active_conns_sli[1])
				mp["local_inactive_conns"] = append(mp["local_inactive_conns"], local_inactive_conns_sli[1])
			}
			i += 50
		}

	}
	return mp
}
