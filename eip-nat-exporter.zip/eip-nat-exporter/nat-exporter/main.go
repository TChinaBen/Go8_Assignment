package main

import (
	"eip-nat-exporter/nat-exporter/collector"
	"eip-nat-exporter/utils"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"net/http"
)

// 单独测试模块

func main() {
	configPath := "C:\\Users\\PENGJIAN\\go\\eip-nat-exporter\\nat-exporter\\config.txt"
	var output = utils.ReadFromConfig(configPath)

	prometheus.MustRegister(collector.NewNatTrafficCollector(output))

	http.Handle("/metrics/", promhttp.Handler())
	http.ListenAndServe(":9999", nil)

}
