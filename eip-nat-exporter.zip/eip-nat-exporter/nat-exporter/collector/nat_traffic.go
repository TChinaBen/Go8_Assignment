package collector

import (
	"github.com/prometheus/client_golang/prometheus"
	"strconv"
	"strings"
)

// nat_traffic{direction="In_Bytes",vni="194"} 0
//nat_traffic{direction="Out_Bytes",vni="194"} 0

type NatTrafficBase struct {
	vni      string
	InBytes  float64
	OutBytes float64
}

func NewNatTrafficBase(output []string) NatTrafficBase {

	vni_str := strings.ReplaceAll(output[1], ":", " ")
	vni_slice := strings.Fields(vni_str)
	//	s2_vni, _ := strconv.Atoi(vni_slice[1])
	in_bytes_str := strings.ReplaceAll(output[8], ":", " ")
	in_bytes_sli := strings.Fields(in_bytes_str)
	s2_in_bytes, _ := strconv.ParseFloat(in_bytes_sli[1], 64)
	out_bytes_str := strings.ReplaceAll(output[9], ":", " ")
	out_bytes_sli := strings.Fields(out_bytes_str)
	s2_out_bytes, _ := strconv.ParseFloat(out_bytes_sli[1], 64)

	return NatTrafficBase{
		vni:      vni_slice[1],
		InBytes:  s2_in_bytes,
		OutBytes: s2_out_bytes,
	}
}

type NatTrafficCollector struct {
	NatTrafficBase
	desc *prometheus.Desc
}

func NewNatTrafficCollector(output []string) *NatTrafficCollector {
	desc := prometheus.NewDesc("nat_traffic", "nat traffic", []string{"vni", "direction"}, nil)

	return &NatTrafficCollector{NewNatTrafficBase(output), desc}
}

func (c *NatTrafficCollector) Describe(descs chan<- *prometheus.Desc) {
	descs <- c.desc
}

func (c *NatTrafficCollector) Collect(metrics chan<- prometheus.Metric) {
	metrics <- prometheus.MustNewConstMetric(c.desc, prometheus.GaugeValue, c.InBytes, c.vni, "In_Bytes")
	metrics <- prometheus.MustNewConstMetric(c.desc, prometheus.GaugeValue, c.OutBytes, c.vni, "Out_Bytes")

}
