package utils

import (
	"bytes"
	"fmt"
	"os/exec"
	"strings"
)

func RunAudit(audit string) (output []string, err error) {
	var out bytes.Buffer
	audit = strings.TrimSpace(audit)
	if len(audit) == 0 {
		return output, err
	}
	cmdArgs := strings.Fields(audit)
	cmd := exec.Command(cmdArgs[0], cmdArgs[1:len(cmdArgs)]...)
	cmd.Stdout = &out
	cmd.Stderr = &out
	err = cmd.Run()
	outputString := out.String()
	output = strings.Split(outputString, "\n")
	fmt.Println(len(output))
	return
}
