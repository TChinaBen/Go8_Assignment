package utils

import (
	"fmt"
	"io/ioutil"
	"strings"
)

func ReadFromConfig(configPath string) []string {
	file, err := ioutil.ReadFile(configPath)
	if err != nil {
		fmt.Println("read fail", err)
	}
	outputString := string(file)
	output := strings.Split(outputString, "\n")
	output = output[:len(output)-1]

	return output
}
